from telethon import TelegramClient, events
from modules.peek import peek
from dotenv import load_dotenv
import asyncio
import os
import csv

load_dotenv()
client = TelegramClient('anon.session', int(os.getenv('API_ID')), os.getenv('API_HASH'))
not_sender_bot = f'https://api.telegram.org/bot{os.getenv('BOT_TOKEN')}/sendmessage?chat_id={os.getenv('CHAT_ID')}'


async def main():
    await client.start()

    bins_store = {}
    try:
        bins_file = open("bins.csv", mode='r', encoding='utf-8')
        reader = csv.DictReader(bins_file)
        for r in reader:
            number = r['number']
            bins_store[number] = {
                'country': r['country'],
                'flag': r['flag'],
                'vendor': r['vendor'],
                'type': r['type'],
                'level': r['level'],
                'bank_name': r['bank_name']
            }
        bins_file.close()
    except Exception as e:
        print(f"failed to load csv file > error: {e}")

    @client.on(events.NewMessage(chats=-1001833380321,incoming=True))
    async def pattern_handler(event):
        print(event.raw_text)
        await peek(event.raw_text, not_sender_bot, bins_store)

    await client.run_until_disconnected()


asyncio.run(main())
